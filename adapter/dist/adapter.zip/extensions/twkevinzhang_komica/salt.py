def encode(s: str) -> str:
    return 'komica1_' + s

def decode(s: str) -> str:
    return s[8:]
