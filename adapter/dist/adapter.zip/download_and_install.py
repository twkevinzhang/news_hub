#TODO: 1. 下載 zip 檔案至 download 資料夾
#TODO: 2. 解壓縮至 extensions/{pkg_name} 資料夾
#TODO: 3. 安裝 {pkg_name}/requirements.txt 中的套件
